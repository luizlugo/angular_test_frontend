export class Image {
  constructor(
    public title: string="",
    public url: string="",
    public description: string=""
  ) {}
}
