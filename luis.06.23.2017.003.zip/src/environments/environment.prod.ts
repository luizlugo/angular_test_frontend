export const environment = {
  production: true,
  api_url: 'http://Test.sjv2piim3g.us-west-2.elasticbeanstalk.com/'
};
